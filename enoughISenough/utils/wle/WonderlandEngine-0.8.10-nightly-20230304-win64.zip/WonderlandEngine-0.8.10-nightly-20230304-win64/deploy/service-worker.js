const CACHE = '{{ settings.project.name }}-static-v1';
const files = [{{ precacheFiles }}];

self.addEventListener('install', event => {
    event.waitUntil(caches.open(CACHE).then(cache => cache.addAll(files) ));
});
self.addEventListener('activate', event => {
    console.log('Service worker initialized.');
});

self.addEventListener('fetch', event => {
    const url = new URL(event.request.url);
    const base = url.pathname.split('?')[0];
    if(url.origin == location.origin && files.includes(base)) {
        event.respondWith(caches.match(base));
    }
});
